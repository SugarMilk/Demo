//
//  GFSocialAlert.h
//  Alert
//
//  Created by 黄健 on 2017/8/2.
//  Copyright © 2017年 黄健. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GFSocialAlert : NSObject

+ (GFSocialAlert *(^)(NSString * title, NSString * message))alert;
- (GFSocialAlert *(^)(NSString * title, dispatch_block_t action))add;
- (GFSocialAlert *(^)())show;

@end

/*
 示例:
 
 GFSocialAlert.alert(@"title", @"message")
 .add(@"确定", ^{
    NSLog(@"1");
 })
 .add(@"取消", nil)
 .add(@"其他", ^{
    NSLog(@"3");
 }).show();
 
 */

