//
//  GFSocialAlert.m
//  Alert
//
//  Created by 黄健 on 2017/8/2.
//  Copyright © 2017年 黄健. All rights reserved.
//

#pragma clang diagnostic push
#pragma clang diagnostic ignored"-Wdeprecated-declarations"

#import <UIKit/UIKit.h>
#import "GFSocialAlert.h"

static GFSocialAlert * instance;

@interface GFSocialAlert () <UIAlertViewDelegate>

@property (nonatomic, strong) UIAlertView * alertView;
@property (nonatomic, retain) NSMutableArray * actionArray;

@end

@implementation GFSocialAlert

+ (GFSocialAlert *(^)(NSString * title, NSString * message))alert {
    return ^GFSocialAlert *(NSString * title, NSString * message) {
        instance = [[GFSocialAlert alloc] init];
        instance.alertView.title = title;
        instance.alertView.message = message;
        instance.alertView.delegate = instance;
        return instance;
    };
}

- (GFSocialAlert *(^)())show {
    return ^GFSocialAlert *() {
        [self.alertView show];
        return self;
    };
}

- (GFSocialAlert *(^)(NSString * title, dispatch_block_t action))add {
    return ^GFSocialAlert *(NSString * title, dispatch_block_t action) {
        if (action == nil) {
            [self.actionArray addObject:@[title, [NSNull null]]];
        } else {
            [self.actionArray addObject:@[title, action]];
        }
        [self.alertView addButtonWithTitle:title];
        return self;
    };
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    id action = [self.actionArray[buttonIndex] lastObject];
    
    if (action != [NSNull null]) {
        dispatch_block_t action_t = action;
        action_t();
    }
}

- (UIAlertView *)alertView {
    if (_alertView == nil) {
        _alertView = [[UIAlertView alloc] init];
    }
    return _alertView;
}

- (NSMutableArray *)actionArray {
    if (_actionArray == nil) {
        _actionArray = [NSMutableArray array];
    }
    return _actionArray;
}

@end

#pragma clang diagnostic pop
