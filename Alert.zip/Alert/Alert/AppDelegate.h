//
//  AppDelegate.h
//  Alert
//
//  Created by 黄健 on 2017/8/2.
//  Copyright © 2017年 黄健. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

