//
//  ViewController.m
//  Alert
//
//  Created by 黄健 on 2017/8/2.
//  Copyright © 2017年 黄健. All rights reserved.
//

#import "ViewController.h"
#import "GFSocialAlert.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
    
    self.view.backgroundColor = [UIColor greenColor];
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    GFSocialAlert.alert(@"title", @"message")
    .add(@"确定", ^{
        NSLog(@"1");
    })
    .add(@"取消", nil)
    .add(@"其他", ^{
        NSLog(@"3");
    }).show();
    
    
//    [[GFSocialAlert shared] addButton:@"确定" action:^{
//        NSLog(@"1");
//    }];
//    [[GFSocialAlert shared] addButton:@"取消" action:nil];
//    [[GFSocialAlert shared] addButton:@"其他" action:^{
//        NSLog(@"3");
//    }];
//    [[GFSocialAlert shared] show:@"title" message:@"message"];
}

@end
