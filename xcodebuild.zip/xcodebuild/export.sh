1.编译生成.framework

xcodebuild 
build 
-project {project_name}.xcodeproj 
-target {target_name} 
-configuration {configuration} 
-sdk {sdk}

2.移动文件
mv {project_dir_name}/build/{configuration}-{sdk}/{framework_name}.framework {save_dir_name}


3.删除文件
rm -rf {project_dir_name}/build/


