//
//  Map.m
//  DataType
//
//  Created by 黄健 on 2017/7/10.
//  Copyright © 2017年 黄健. All rights reserved.
//

#import "Map.h"

@interface Map ()

@property (nonatomic, retain) NSMutableArray * array;

@end

@implementation Map

+ (Map *(^)())map {
    return ^Map *() {
        return [[self alloc] init];
    };
}

- (Map *(^)(NSString * key, NSSet * values))add {
    return ^Map *(NSString * key, NSSet * values) {
        NSLog(@"add:%@", key);
        
        NSInteger index = self.index(key);
        if (index == -1) {
            [self.array addObject:[NSMutableArray arrayWithObjects:key, [NSMutableSet setWithSet:values], nil]];
        }
        return self;
    };
}

- (Map *(^)(NSString * key, id value))appendValue {
    return ^Map *(NSString * key, id value) {
        NSInteger index = self.index(key);
        NSMutableSet * set = self.array[index][1];
        [set addObject:value];
        return self;
    };
}

- (Map *(^)(NSString * key, id value))removeValue {
    return ^Map *(NSString * key, id value) {
        NSInteger index = self.index(key);
        NSMutableSet * set = self.array[index][1];
        [set removeObject:value];
        return self;
    };
}

- (Map *(^)(NSString * key))cut {
    return ^Map *(NSString * key) {
        NSInteger index = self.index(key);
        NSMutableSet * set = self.array[index][1];
        [set removeAllObjects];
        return self;
    };
}

- (NSSet *(^)(NSString * key))values {
    return ^NSSet *(NSString * key) {
        NSInteger index = self.index(key);
        return self.array[index][1];
    };
}

- (BOOL(^)(NSString * key, id value))containValue {
    return ^BOOL(NSString * key, id value) {
        NSInteger index = self.index(key);
        NSMutableSet * set = self.array[index][1];
        return [set containsObject:value];
    };
}

- (NSInteger(^)(NSString * key))index {
    return ^NSInteger(NSString * key) {
        NSInteger count = 0;
        for (NSArray * item in self.array) {
            if ([item.firstObject isEqualToString:key]) {
                return count;
            }
            count = count + 1;
        }
        return -1;
    };
}

- (NSMutableArray *)array {
    if (_array == nil) {
        _array = [NSMutableArray array];
    }
    return _array;
}


- (NSString *)description {
    NSMutableString * string = [NSMutableString string];
    [string appendString:@"\n>>> Map\n"];
    for (NSArray * item in self.array) {
        [string appendFormat:@"{%@ - %@},\n", item.firstObject, ((NSSet *)item.lastObject).allObjects];
    }
    [string appendString:@"<<<\n"];
    return string;
}

@end
