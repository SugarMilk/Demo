//
//  Map.h
//  DataType
//
//  Created by 黄健 on 2017/7/10.
//  Copyright © 2017年 黄健. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Map : NSObject

+ (Map *(^)())map;
- (Map *(^)(NSString * key, NSSet * values))add;
- (Map *(^)(NSString * key, id value))appendValue;
- (Map *(^)(NSString * key, id value))removeValue;
- (Map *(^)(NSString * key))cut;
- (NSSet *(^)(NSString * key))values;
- (BOOL(^)(NSString * key, id value))containValue;

@end
