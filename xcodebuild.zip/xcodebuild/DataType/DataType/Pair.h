//
//  Pair.h
//  DataType
//
//  Created by 黄健 on 2017/7/10.
//  Copyright © 2017年 黄健. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Pair : NSObject

+ (Pair *(^)())pair;
- (Pair *(^)(NSString * key, id value))update;
- (Pair *(^)(NSString * key))remove;
- (NSInteger(^)(NSString * key))index;
- (id(^)(NSString * key))value;
- (NSArray *(^)())allKeys;

@end
