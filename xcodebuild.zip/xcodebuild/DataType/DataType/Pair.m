//
//  Pair.m
//  DataType
//
//  Created by 黄健 on 2017/7/10.
//  Copyright © 2017年 黄健. All rights reserved.
//

#import "Pair.h"

@interface Pair ()

@property (nonatomic, retain) NSMutableArray * array;

@end


@implementation Pair

+ (Pair *(^)())pair {
    return ^Pair *() {
        return [[self alloc] init];
    };
}

- (Pair *(^)(NSString * key, id value))update {
    return ^Pair *(NSString * key, id value) {
        NSInteger index = self.index(key);
        if (index != -1) {
            [self.array replaceObjectAtIndex:index withObject:@[key, value]];
        } else {
            [self.array addObject:@[key, value]];
        }
        return self;
    };
}

- (Pair *(^)(NSString * key))remove {
    return ^Pair *(NSString * key) {
        NSInteger index = self.index(key);
        if (index != -1) {
            [self.array removeObjectAtIndex:index];
        }
        return self;
    };
}

- (NSInteger(^)(NSString * key))index {
    return ^NSInteger(NSString * key) {
        NSInteger count = 0;
        for (NSArray * item in self.array) {
            if ([item.firstObject isEqualToString:key]) {
                return count;
            }
            count = count + 1;
        }
        return -1;
    };
}

- (id(^)(NSString * key))value {
    return ^id(NSString * key) {
        for (NSArray * item in self.array) {
            if ([item.firstObject isEqualToString:key]) {
                return item.lastObject;
            }
        }
        return nil;
    };
}

- (NSArray *(^)())allKeys {
    return ^NSArray *(NSString * key) {
        NSMutableArray * array = [NSMutableArray arrayWithCapacity:self.array.count];
        for (NSArray * item in self.array) {
            [array addObject:item.firstObject];
        }
        return array;
    };
}

- (NSMutableArray *)array {
    if (_array == nil) {
        _array = [NSMutableArray array];
    }
    return _array;
}

- (NSString *)description {
    NSMutableString * string = [NSMutableString string];
    [string appendString:@"\n>>> Pair\n"];
    for (NSArray * item in self.array) {
        [string appendFormat:@"{%@ - %@},\n", item.firstObject, item.lastObject];
    }
    [string appendString:@"<<<\n"];
    return string;
}

@end
