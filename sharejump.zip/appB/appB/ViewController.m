//
//  ViewController.m
//  appB
//
//  Created by 黄健 on 2017/7/29.
//  Copyright © 2017年 黄健. All rights reserved.
//

#import "ViewController.h"
#import "GFOpenURL.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    self.view.backgroundColor = [UIColor greenColor];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    NSURL * url = [GFOpenURL shared].currentURL;
    
    if ([[UIApplication sharedApplication] canOpenURL:url]) {
        [[UIApplication sharedApplication] openURL:url];
    }
}

@end
