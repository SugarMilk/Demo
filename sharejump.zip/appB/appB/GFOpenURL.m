//
//  GFOpenURL.m
//  appB
//
//  Created by 黄健 on 2017/7/29.
//  Copyright © 2017年 黄健. All rights reserved.
//

#import "GFOpenURL.h"

@implementation GFOpenURL

+ (instancetype)shared {
    static id instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

@end
