//
//  AppDelegate.h
//  appA
//
//  Created by 黄健 on 2017/7/29.
//  Copyright © 2017年 黄健. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

